/*
Output for this main is inside output.txt
Note that output.txt is what my program prints when running this main, thus you should get exactly the same output as the textfile
*/
#include "node.h"

int main()
{
    node *list1 = new node(2);
    list1->insert(4);
    list1->insert(6);
    list1->insert(8);
    list1->insert(10);

    node *list2 = new node(5);
    list2->insert(1);
    list2->insert(3);
    list2->insert(7);
    list2->insert(9);

    list1->print();
    list2->print();

    list1->insert(list2);
    list1->print();
    list2->print();

    list1->destroyList();
    return 0;
}