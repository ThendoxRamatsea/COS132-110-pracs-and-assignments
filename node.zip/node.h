#include <iostream>

class node
{
public:
    int data;
    node *next;
    node *prev;

    node(int val);
    ~node();
    void destroyList();
    bool contains(int val);
    void insert(int val);
    void insert(node *n);
    void print();
    int length();
    node *remove(int val);
    node *head();
    node *tail();
};
