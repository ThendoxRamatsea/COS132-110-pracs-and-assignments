#include "node.h"

node::node(int val)
{
    data = val;
    next = NULL;
    prev = NULL;
}

node::~node()
{
    next = NULL;
    prev = NULL;
}

void node::destroyList()
{
    node *current = this;
    while (current != NULL)
    {
        node *nextnode = current->next;
        delete current;
        current = nextnode;
    }
}

bool node::contains(int val)
{
    node *current = this;
    while (current != NULL)
    {
        if (current->data == val)
            return true;
        current = current->next;
    }
    current = this->prev;
    while (current != NULL)
    {
        if (current->data == val)
            return true;
        current = current->prev;
    }
    return false;
}

void node::insert(int val)
{
    if (contains(val))
        return;

    node *newnode = new node(val);
    if (newnode->data < this->data)
    {
        newnode->next = this;
        if (this->prev != NULL)
        {
            this->prev->next = newnode;
            newnode->prev = this->prev;
        }
        this->prev = newnode;
    }
    else
    {
        node *current = this;
        while (current->next != NULL && current->next->data < newnode->data)
        {
            current = current->next;
        }
        newnode->next = current->next;
        newnode->prev = current;
        if (current->next != NULL)
            current->next->prev = newnode;
        current->next = newnode;
    }
}

void node::insert(node *n)
{
    if (n == NULL || contains(n->data))
        return;

    node *current = n;
    while (current != NULL)
    {
        int val = current->data;
        node *nextnode = current->next;
        if (!contains(val))
        {
            insert(val);
        }
        delete current;     // delete node from the passed-in list
        current = nextnode; // move to the next node
    }
}

void node::print()
{
    node *headnode = head();
    while (headnode != NULL)
    {
        if (headnode == this)
            std::cout << "[" << headnode->data << "]";
        else
            std::cout << headnode->data;

        if (headnode->next != NULL)
            std::cout << "->";

        headnode = headnode->next; // move to the next node
    }
    std::cout << std::endl; // end of line
}

int node::length()
{
    int len = 0;
    node *currentnode = this;

    while (currentnode && currentnode->prev)
        currentnode = currentnode->prev;

    while (currentnode)
    {
        len++;
        currentnode = currentnode->next;
    }

    return len;
}

node *node::remove(int val)
{
    node *currentnode = this;

    while (currentnode && currentnode->data != val)
        currentnode = currentnode->next;

    if (!currentnode)
        return NULL;

    if (currentnode->prev)
        currentnode->prev->next = currentnode->next;

    if (currentnode->next)
        currentnode->next->prev = currentnode->prev;

    currentnode->next = NULL;
    currentnode->prev = NULL;

    return currentnode;
}

node *node::head()
{
    node *currentnode = this;

    while (currentnode && currentnode->prev)
        currentnode = currentnode->prev;

    return currentnode;
}

node *node::tail()
{
    node *currentnode = this;

    while (currentnode && currentnode->next)
        currentnode = currentnode->next;

    return currentnode;
}
