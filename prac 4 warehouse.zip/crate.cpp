#include "crate.h"
#include <iomanip>
#include <sstream>

// Constructors
crate::crate()
{

    name = "empty";
    amount = 0;
    price = 0.0;
}

crate::crate(std::string name, int amount, float price)
{
    this->name = name;
    this->amount = amount;
    this->price = price;
}

crate::crate(const crate &other)
{
    name = other.name;
    amount = other.amount;
    price = other.price;
}
crate::crate(std::string s)
{
    name = "empty";
    amount = 0;
    price = 0.0;
    *this | s;
}

// Setters
void crate::setName(std::string name) { this->name = name; }
void crate::setAmount(int amount) { this->amount = amount; }
void crate::setPrice(float price) { this->price = price; }

// Getters
std::string crate::getName() { return name; }
int crate::getAmount() { return amount; }
float crate::getPrice() { return price; }

// Value
float crate::getValue() { return amount * price; }

// Increment and decrement operators
crate &crate::operator++()
{

    amount++;
    return *this;
}
crate crate::operator++(int)
{

    crate temp(*this);
    amount++;
    return temp;
}
crate &crate::operator+=(int a)
{
    amount += a;
    if (amount <= 0)
    {
        // If amount is less than or equal to 0, set member variables to show an empty crate
        name = "";
        price = 0.0;
    }
    return *this;
}
crate &crate::operator-=(int a)
{
    amount -= a;
    if (amount <= 0)
    {
        // If amount is less than or equal to 0, set member variables to show an empty crate
        name = "";
        price = 0.0;
    }
    return *this;
}

// Comparison operators
bool crate::operator==(crate &other)
{
    return (name == other.name && price == other.price);
}
bool crate::operator<=(crate &other)
{
    return (name <= other.name);
}
bool crate::operator>=(crate &other)
{
    return (name >= other.name);
}
bool crate::operator<(crate &other)
{
    return (amount * price < other.amount * other.price);
}
bool crate::operator>(crate &other)
{
    return (amount * price > other.amount * other.price);
}

// Friend functions
std::ostream &operator<<(std::ostream &os, crate &c)
{
    os << std::left << std::setw(50) << c.name
       << std::setw(10) << c.amount
       << "R " << std::setw(8) << std::fixed << std::setprecision(2) << c.price
       << "R " << std::setw(8) << std::fixed << std::setprecision(2) << (c.getAmount() * c.getPrice())
       << std::endl;
    return os;
}

std::istream &operator>>(std::istream &is, crate &c)
{
    std::string line;
    getline(is, line);
    c | line;
    return is;
}
int stringToInt(const std::string &str)
{
    int result = 0;
    std::istringstream iss(str);
    iss >> result;
    return result;
}

// Helper function to convert string to float
float stringToFloat(const std::string &str)
{
    float result = 0.0f;
    std::istringstream iss(str);
    iss >> result;
    return result;
}

// Operator overloading
crate &crate::operator|(std::string input)
{
    std::stringstream ss(input);
    std::string token;

    // Extract name
    if (getline(ss, token, '|'))
    {
        if (!token.empty())
            setName(token);
    }

    // Extract amount
    if (getline(ss, token, '|'))
    {
        if (!token.empty())
            setAmount(stringToInt(token));
    }

    // Extract price
    if (getline(ss, token, '|'))
    {
        if (!token.empty())
            setPrice(stringToFloat(token));
    }

    return *this;
}