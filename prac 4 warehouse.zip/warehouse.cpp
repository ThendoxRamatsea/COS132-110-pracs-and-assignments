#include "warehouse.h"
#include <iomanip>
#include <sstream>

warehouse::warehouse() : numCrates(0), crates(NULL) {}
warehouse::warehouse(int numCrates)
{
    this->numCrates = numCrates;
    crates = new crate *[numCrates];
    for (int i = 0; i < numCrates; i++)
    {
        crates[i] = new crate();
    }
}

warehouse::warehouse(int numCrates, crate **crates)
{

    this->numCrates = numCrates;
    this->crates = new crate *[numCrates];
    for (int i = 0; i < numCrates; i++)
    {
        this->crates[i] = new crate(*crates[i]);
    }
}

warehouse::warehouse(const warehouse &w)
{
    this->numCrates = w.numCrates;
    crates = new crate *[numCrates];
    for (int i = 0; i < numCrates; i++)
    {
        crates[i] = new crate(*w.crates[i]);
    }
}

int warehouse::getNumCrates() { return numCrates; }
crate **warehouse::getCrates() { return crates; }

float warehouse::getValue()
{
    float totalValue = 0.0;
    for (int i = 0; i < numCrates; i++)
    {
        if (crates[i] != NULL)
        {
            totalValue += crates[i]->getAmount() * crates[i]->getPrice();
        }
    }
    return totalValue;
}
std::ostream &operator<<(std::ostream &os, warehouse &w)
{
    os << std::string(80, '-') << std::endl;

    crate **crates = w.getCrates();
    for (int i = 0; i < w.getNumCrates(); i++)
    {
        if (crates[i] != NULL)
        {
            os << *crates[i];
        }
    }

    os << std::string(80, '-') << std::endl;

    std::cout << "Warehouse" << std::right << std::setw(50) << w.numCrates << std::setw(10) << " " << std::setw(10) << "R " << std::setw(2) << std::setw(8) << std::fixed << std::setprecision(2) << w.getValue() << std::endl;

    os << std::string(80, '-') << std::endl;

    return os;
}

std::istream &operator>>(std::istream &is, warehouse &w)
{
    int Cratesadded;
    is >> Cratesadded;

    if (w.crates != NULL)
    {
        for (int i = 0; i < w.numCrates; i++)
        {
            delete w.crates[i];
        }
        delete[] w.crates;
    }

    w.numCrates = Cratesadded;
    w.crates = new crate *[Cratesadded];

    while (is.get() != '\n')
        ;

    for (int i = 0; i < Cratesadded; i++)
    {
        crate newCrate;
        is >> newCrate;
        w.crates[i] = new crate(newCrate);
    }

    return is;
}

warehouse &warehouse::operator+=(crate &c)
{
    bool crateFound = false;
    for (int i = 0; i < numCrates; i++)
    {
        if (crates[i] != NULL && *crates[i] == c)
        {

            crates[i]->setAmount(crates[i]->getAmount() + c.getAmount());
            crateFound = true;
            break;
        }
    }

    if (!crateFound)
    {
        for (int i = 0; i < numCrates; i++)
        {
            if (crates[i] == NULL)
            {

                crates[i] = new crate(c);
                return *this;
            }
        }

        int newSize = numCrates + 1;
        crate **newCrates = new crate *[newSize];

        for (int i = 0; i < numCrates; i++)
        {
            newCrates[i] = crates[i];
        }

        newCrates[numCrates] = new crate(c);

        delete[] crates;
        crates = newCrates;
        numCrates = newSize;
    }

    return *this;
}

warehouse &warehouse::operator-=(crate &c)
{
    for (int i = 0; i < numCrates; i++)
    {
        if (crates[i] != NULL && *crates[i] == c)
        {
            int currentAmount = crates[i]->getAmount();
            int decreaseAmount = c.getAmount();

            currentAmount -= decreaseAmount;
            if (currentAmount < 0)
            {
                currentAmount = 0;
            }

            crates[i]->setAmount(currentAmount);
            break;
        }
    }

    return *this;
}

warehouse warehouse::operator|(int method)
{
    warehouse sortedWarehouse(numCrates);

    for (int i = 0; i < numCrates; i++)
    {
        sortedWarehouse.crates[i] = new crate(*crates[i]);
    }

    if (method == 0)
    {
        bool swapped;
        do
        {
            swapped = false;
            for (int i = 0; i < sortedWarehouse.numCrates - 1; i++)
            {
                if (sortedWarehouse.crates[i]->getName() > sortedWarehouse.crates[i + 1]->getName() ||
                    (sortedWarehouse.crates[i]->getName() == sortedWarehouse.crates[i + 1]->getName() &&
                     sortedWarehouse.crates[i]->getValue() > sortedWarehouse.crates[i + 1]->getValue()))
                {

                    crate *temp = sortedWarehouse.crates[i];
                    sortedWarehouse.crates[i] = sortedWarehouse.crates[i + 1];
                    sortedWarehouse.crates[i + 1] = temp;
                    swapped = true;
                }
            }
        } while (swapped);
    }
    else if (method > 0)
    {

        bool swapped;
        do
        {
            swapped = false;
            for (int i = 0; i < sortedWarehouse.numCrates - 1; i++)
            {
                if (sortedWarehouse.crates[i]->getValue() > sortedWarehouse.crates[i + 1]->getValue() ||
                    (sortedWarehouse.crates[i]->getValue() == sortedWarehouse.crates[i + 1]->getValue() &&
                     sortedWarehouse.crates[i]->getName() > sortedWarehouse.crates[i + 1]->getName()))
                {

                    crate *temp = sortedWarehouse.crates[i];
                    sortedWarehouse.crates[i] = sortedWarehouse.crates[i + 1];
                    sortedWarehouse.crates[i + 1] = temp;
                    swapped = true;
                }
            }
        } while (swapped);
    }
    else
    {

        bool swapped;
        do
        {
            swapped = false;
            for (int i = 0; i < sortedWarehouse.numCrates - 1; i++)
            {
                if (sortedWarehouse.crates[i]->getValue() < sortedWarehouse.crates[i + 1]->getValue() ||
                    (sortedWarehouse.crates[i]->getValue() == sortedWarehouse.crates[i + 1]->getValue() &&
                     sortedWarehouse.crates[i]->getName() > sortedWarehouse.crates[i + 1]->getName()))
                {

                    crate *temp = sortedWarehouse.crates[i];
                    sortedWarehouse.crates[i] = sortedWarehouse.crates[i + 1];
                    sortedWarehouse.crates[i + 1] = temp;
                    swapped = true;
                }
            }
        } while (swapped);
    }

    return sortedWarehouse;
}

warehouse &warehouse::operator|=(int method)
{
    if (method == 0)
    {
        bool swapped;
        do
        {
            swapped = false;
            for (int i = 0; i < numCrates - 1; i++)
            {
                if (crates[i]->getName() > crates[i + 1]->getName() ||
                    (crates[i]->getName() == crates[i + 1]->getName() &&
                     crates[i]->getValue() > crates[i + 1]->getValue()))
                {

                    std::swap(crates[i], crates[i + 1]);
                    swapped = true;
                }
            }
        } while (swapped);
    }
    else if (method > 0)
    {

        bool swapped;
        do
        {
            swapped = false;
            for (int i = 0; i < numCrates - 1; i++)
            {
                if (crates[i]->getValue() > crates[i + 1]->getValue() ||
                    (crates[i]->getValue() == crates[i + 1]->getValue() &&
                     crates[i]->getName() > crates[i + 1]->getName()))
                {

                    std::swap(crates[i], crates[i + 1]);
                    swapped = true;
                }
            }
        } while (swapped);
    }
    else
    {

        bool swapped;
        do
        {
            swapped = false;
            for (int i = 0; i < numCrates - 1; i++)
            {
                if (crates[i]->getValue() < crates[i + 1]->getValue() ||
                    (crates[i]->getValue() == crates[i + 1]->getValue() &&
                     crates[i]->getName() > crates[i + 1]->getName()))
                {

                    std::swap(crates[i], crates[i + 1]);
                    swapped = true;
                }
            }
        } while (swapped);
    }

    return *this;
}

crate &warehouse::operator[](int idx)
{
    if (idx >= 0 && idx < numCrates)
    {
        return *(crates[idx]);
    }
    else
    {
        int maxIndex = 0;
        for (int i = 1; i < numCrates; i++)
        {
            if (crates[i]->getValue() > crates[maxIndex]->getValue())
            {
                maxIndex = i;
            }
            else if (crates[i]->getValue() == crates[maxIndex]->getValue())
            {

                if (crates[i]->getName() < crates[maxIndex]->getName())
                {
                    maxIndex = i;
                }
            }
        }
        return *(crates[maxIndex]);
    }
}

warehouse &warehouse::operator()()
{
    int nonEmptyCount = 0;

    for (int i = 0; i < numCrates; i++)
    {
        if (crates[i]->getAmount() > 0)
        {
            nonEmptyCount++;
        }
    }

    crate **nonEmptyCrates = new crate *[nonEmptyCount];

    int newIndex = 0;

    for (int i = 0; i < numCrates; i++)
    {
        if (crates[i]->getAmount() > 0)
        {
            nonEmptyCrates[newIndex] = crates[i];
            newIndex++;
        }
    }

    delete[] crates;

    numCrates = nonEmptyCount;
    crates = nonEmptyCrates;

    return *this;
}

warehouse &warehouse::operator()(crate &c)
{
    int nonEmptyCount = 0;

    for (int i = 0; i < numCrates; i++)
    {
        if (crates[i]->getAmount() > 0 && !(*crates[i] == c))
        {
            nonEmptyCount++;
        }
    }

    crate **nonEmptyCrates = new crate *[nonEmptyCount];

    int newIndex = 0;

    for (int i = 0; i < numCrates; i++)
    {
        if (crates[i]->getAmount() > 0 && !(*crates[i] == c))
        {
            nonEmptyCrates[newIndex] = crates[i];
            newIndex++;
        }
    }

    delete[] crates;

    numCrates = nonEmptyCount;
    crates = nonEmptyCrates;

    return *this;
}
warehouse::~warehouse()
{
    for (int i = 0; i < numCrates; ++i)
    {
        delete crates[i];
        crates[i] = NULL;
    }
    delete[] crates;
}
