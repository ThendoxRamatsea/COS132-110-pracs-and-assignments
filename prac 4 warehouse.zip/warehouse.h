#ifndef WAREHOUSE_H
#define WAREHOUSE_H

#include <iostream>
#include "crate.h"

class warehouse
{
private:
    // Members
    int numCrates;
    crate **crates;

public:
    // Constructors
    warehouse();
    warehouse(int numCrates);
    warehouse(int numCrates, crate **crates);

    // Copy constructor
    warehouse(const warehouse &w);

    // Destructor
    ~warehouse();

    // Getters
    int getNumCrates();
    crate **getCrates();

    // Value
    float getValue();
    warehouse &operator+=(crate &c);
    warehouse &operator-=(crate &c);

    // Sorting operators
    warehouse operator|(int method);
    warehouse &operator|=(int method);
    // Indexing operator
    crate &operator[](int index);

    // Clear operators
    warehouse &operator()();
    warehouse &operator()(crate &c);

    // Friend functions
    friend std::ostream &operator<<(std::ostream &os, warehouse &w);
    friend std::istream &operator>>(std::istream &is, warehouse &w);

    /*static bool sortByName(crate *a, crate *b);
    static bool sortByValueAscending(crate *a, crate *b);
    static bool sortByValueDescending(crate *a, crate *b);*/
};

#endif
