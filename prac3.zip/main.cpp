#include <iostream>
#include <fstream>
#include "MyString.h"

int main()
{

    MyString s1;
    s1.print();

    MyString s2("abc123");
    s2.print(); // should print "abc123"

    // Test cleanString function
    MyString x("aBC % $k$48J f {} d 1 2 kl - D 3");
    x.print(); // should
    std::string dirty = "aBC % $k$48J f {} d 1 2 kl - D 3";
    // should print "aBCk48Jfd12klD3"

    MyString s3 = s2 + dirty;
    s3.print(); // should print "abc123aBCk48Jfd12klD3"

    MyString s4 = s2 + s3;
    s4.print(); // should print "abc123abc123aBCk48Jfd12klD3"

    s4 += s2;
    s4.print(); // should print "abc123abc123aBCk48Jfd12klD3abc123"

    // Test operator! and clear functions
    if (!s4)
    {
        std::cout << "s4 is empty" << std::endl;
    }
    else
    {
        std::cout << "s4 is not empty" << std::endl; // should print "s4 is not empty"
        s4.clear();
        if (!s4)
        {
            std::cout << "s4 is empty" << std::endl; // should print "s4 is empty"
        }
    }

    s4 = dirty;
    s4.print(); // should print "aBCk48Jfd12klD3"

    s4 = s2;
    s4.print(); // should print "abc123"

    // Test operator= with fstream argument
    std::fstream file("test.txt");
    if (file.is_open())
    {
        s4 = file;
        s4.print();
    }
    else
    {
        std::cout << "Failed to open test.txt" << std::endl;
    }

    return 0;
}
