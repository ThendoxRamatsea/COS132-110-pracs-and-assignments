#include <iostream>
#include "MyString.h"
#include <fstream>
#include <sstream>
#include <stdlib.h>
using namespace std;
MyString::MyString()
{
    this->mString = " ";
    this->mString.resize(0);
}

std::string MyString::cleanString(std::string dirtyString)
{
    std::string result;
    for (std::string::const_iterator it = dirtyString.begin(); it != dirtyString.end(); ++it)
    {
        if ((*it >= 'A' && *it <= 'Z') || (*it >= 'a' && *it <= 'z') || (*it >= '0' && *it <= '9'))
        {
            result += *it;
        }
    }
    return result;
}

MyString::MyString(std::string instring)
{

    if (instring.empty())
    {
        this->mString = instring;
    }
    else
    {
        cleanString(instring);
        this->mString = instring;
    }
}

MyString::~MyString() {}

void MyString::print()
{

    std::cout << this->mString << endl;
}
std::string MyString::operator+(std::string rhs)
{

    std::string newString;
    newString = this->mString + cleanString(rhs);
    return newString;
}
std::string MyString::operator+(const MyString &rhs)
{
    return this->mString + rhs.mString;
}
MyString &MyString::operator+=(const MyString &rhs)
{
    mString += rhs.mString;
    return *this;
}
bool MyString::operator<(const MyString &rhs)
{
    std::string left = mString;
    std::string right = rhs.mString;
    for (size_t i = 0; i < left.length() && i < right.length(); ++i)
    {
        if (left[i] != right[i])
        {
            if ((left[i] >= '0' && left[i] <= '9') && (right[i] >= '0' && right[i] <= '9'))
            {
                return left[i] < right[i];
            }
            else if (left[i] >= '0' && left[i] <= '9')
            {
                return true;
            }
            else if (right[i] >= '0' && right[i] <= '9')
            {
                return false;
            }
            else
            {
                return left[i] < right[i];
            }
        }
    }
    return left.length() < right.length();
}
bool MyString::operator>(const MyString &rhs)
{
    return mString > rhs.mString;
}
bool MyString::operator==(const MyString &rhs)
{
    return mString == rhs.mString;
}
bool MyString::operator!=(const MyString &rhs)
{
    return !(*this == rhs);
}
//! i need to code the remainder of the overloaded operators

MyString &MyString::operator=(const std::string input)
{
    mString = cleanString(input);
    return *this;
}
MyString &MyString::operator=(const MyString &rhs)
{
    mString = rhs.mString;
    return *this;
}

#include <fstream>

MyString &MyString::operator=(std::fstream &file)
{
    if (file.fail())
    {
        return *this;
    }
    mString = "";
    char c;
    while (file.get(c))
    {
        mString += c;
    }
    return *this;
}

bool MyString::operator!()
{
    return mString.empty();
}
void MyString::clear()
{
    mString = "";
}
