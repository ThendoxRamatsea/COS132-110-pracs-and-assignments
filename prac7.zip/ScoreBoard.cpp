#ifndef ScoreBoard_CPP
#define ScoreBoard_CPP
#include "ScoreBoard.h"
#include <iostream>
template <typename T>
ScoreBoard<T>::ScoreBoard(){};
template <typename T>
ScoreBoard<T>::~ScoreBoard(){};

template <typename T>

void ScoreBoard<T>::addScore(std::string user, T score)
{
    if (scores.exists(user))
    {
        if (score > scores.at(user))
        {
            scores.set(user, score);
        }
    }
    else
    {
        scores.set(user, score);
    }
}
template <typename T>
void ScoreBoard<T>::removeScore(std::string user)
{
    scores.removeAt(user);
}
template <typename T>
T ScoreBoard<T>::getScore(std::string user)
{
    return scores.at(user);
}
template <typename T>

T ScoreBoard<T>::getHighScore()
{
    if (scores.size() == 0)
    {
        return T();
    }

    T highScore = scores.at(scores.getKeys()[0]);
    for (int i = 1; i < scores.size(); ++i)
    {
        T score = scores.at(scores.getKeys()[i]);
        if (score > highScore)
        {
            highScore = score;
        }
    }

    return highScore;
}
template <typename T>
Tuple<int, std::string *> ScoreBoard<T>::getHighScoreUser()
{
    T highScore = getHighScore();
    int count = 0;
    for (int i = 0; i < scores.size(); ++i)
    {
        if (scores.at(scores.getKeys()[i]) == highScore)
        {
            ++count;
        }
    }

    std::string *users = new std::string[count];
    for (int i = 0, j = 0; i < scores.size(); ++i)
    {
        if (scores.at(scores.getKeys()[i]) == highScore)
        {
            users[j] = scores.getKeys()[i];
            ++j;
        }
    }

    return Tuple<int, std::string *>(count, users);
}

#endif