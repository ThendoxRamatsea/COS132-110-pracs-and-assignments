#include <iostream>
#include "Dictionary.h"
#include "Dictionary.cpp"
#include "Tuple.h"
#include "Tuple.cpp"
#include "ScoreBoard.h"
#include "ScoreBoard.cpp"

using namespace std;

int main()
{
    Dictionary<std::string, int> dictionary;

    dictionary.set("Alice", 100);
    dictionary.set("Bob", 75);
    dictionary.set("Charlie", 90);

    std::cout << "Bob's score: " << dictionary.at("Bob") << std::endl; // Should print 75

    dictionary.removeAt("Bob");
    std::cout << "Bob's score after removal: " << dictionary.at("Bob") << std::endl; // Should print the default value (0)

    // Test ScoreBoard class
    ScoreBoard<int> scoreboard;

    scoreboard.addScore("Alice", 150);
    scoreboard.addScore("Bob", 120);
    scoreboard.addScore("Charlie", 160);

    std::cout << "Charlie's score: " << scoreboard.getScore("Charlie") << std::endl; // Should print 160

    scoreboard.removeScore("Bob");
    std::cout << "Bob's score after removal: " << scoreboard.getScore("Bob") << std::endl; // Should print the default value (0)

    std::cout << "High Score: " << scoreboard.getHighScore() << std::endl; // Should print 160

    Tuple<int, std::string *> highScoreUsers = scoreboard.getHighScoreUser();
    std::cout << "High Score Users: ";
    for (int i = 0; i < highScoreUsers.getFirst(); i++)
    {
        std::cout << highScoreUsers.getSecond()[i] << " ";
    }
    std::cout << std::endl;

    return 0;
}
