#ifndef DICTIONARY_CPP
#define DICTIONARY_CPP
#include "Dictionary.h"
#include <cstddef>
template <class T, class E>
Dictionary<T, E>::Dictionary()
{
    currSize = 0;
    keys = NULL;
    values = NULL;
    if (currSize == 0)
    {
        delete[] keys;
        delete[] values;
        keys = NULL;
        values = NULL;
    }
};
template <typename T, typename E>
Dictionary<T, E>::~Dictionary()
{
    if (keys != NULL)
    {

        delete[] keys;
        keys = NULL;
    }
    if (values != NULL)
    {
        delete[] values;
        values = NULL;
    }
}
template <typename T, typename E>
void Dictionary<T, E>::set(T key, E value)
{
    for (int i = 0; i < currSize; ++i)
    {
        if (keys[i] == key)
        {
            values[i] = value;
            return;
        }
    }
    T *newKeys = new T[currSize + 1];
    E *newValues = new E[currSize + 1];

    for (int i = 0; i < currSize; ++i)
    {
        newKeys[i] = keys[i];
        newValues[i] = values[i];
    }

    newKeys[currSize] = key;
    newValues[currSize] = value;

    delete[] keys;
    delete[] values;
    keys = NULL;
    values = NULL;

    keys = newKeys;
    values = newValues;

    ++currSize;
}
template <typename T, typename E>
E Dictionary<T, E>::at(T key)
{
    for (int i = 0; i < currSize; ++i)
    {
        if (keys[i] == key)
        {
            return values[i];
        }
    }
    return E();
}
template <typename T, typename E>
void Dictionary<T, E>::removeAt(T key)
{
    int index = -1;
    for (int i = 0; i < currSize; ++i)
    {
        if (keys[i] == key)
        {
            index = i;
            break;
        }
    }

    if (index != -1)
    { // if key found
        T *newKeys = new T[currSize - 1];
        E *newValues = new E[currSize - 1];

        for (int i = 0, j = 0; i < currSize; ++i)
        {
            if (i != index)
            { // skip the removed element
                newKeys[j] = keys[i];
                newValues[j] = values[i];
                ++j;
            }
        }

        delete[] keys;
        delete[] values;
        keys = NULL;
        values = NULL;

        keys = newKeys;
        values = newValues;

        --currSize;

        if (currSize == 0)
        { // if all items are removed
            delete[] keys;
            delete[] values;
            keys = NULL;
            values = NULL;
        }
    }
}
template <typename T, typename E>
void Dictionary<T, E>::remove(E value)
{
    int count = 0;
    for (int i = 0; i < currSize; ++i)
    {
        if (values[i] == value)
        {
            ++count;
        }
    }

    if (count > 0)
    { // if value found
        T *newKeys = new T[currSize - count];
        E *newValues = new E[currSize - count];

        for (int i = 0, j = 0; i < currSize; ++i)
        {
            if (values[i] != value)
            { // skip the removed elements
                newKeys[j] = keys[i];
                newValues[j] = values[i];
                ++j;
            }
        }

        delete[] keys;
        delete[] values;
        keys = NULL;
        values = NULL;

        keys = newKeys;
        values = newValues;

        currSize -= count;

        if (currSize == 0)
        { // if all items are removed
            delete[] keys;
            delete[] values;
            keys = NULL;
            values = NULL;
        }
    }
}
template <typename T, typename E>
bool Dictionary<T, E>::exists(T key)
{
    for (int i = 0; i < currSize; ++i)
    {
        if (keys[i] == key)
        {
            return true;
        }
    }
    return false;
}
template <typename T, typename E>
void Dictionary<T, E>::swap(T firstkey, T secondkey)
{
    int firstIndex = -1, secondIndex = -1;
    for (int i = 0; i < currSize; ++i)
    {
        if (keys[i] == firstkey)
            firstIndex = i;
        if (keys[i] == secondkey)
            secondIndex = i;
    }

    if (firstIndex != -1 && secondIndex != -1)
    { // if both keys found
        E temp = values[firstIndex];
        values[firstIndex] = values[secondIndex];
        values[secondIndex] = temp;
    }
}
template <typename T, typename E>
void Dictionary<T, E>::clear()
{
    delete[] keys;
    delete[] values;
    keys = NULL;
    values = NULL;
    currSize = 0;
}
template <typename T, typename E>
T *Dictionary<T, E>::getKeys()
{
    return keys;
}
template <typename T, typename E>
int Dictionary<T, E>::size()
{

    return currSize;
}
template <typename T, typename E>
Tuple<int, T *> Dictionary<T, E>::keysWithValue(E value)
{
    int count = 0;
    for (int i = 0; i < currSize; ++i)
    {
        if (values[i] == value)
        {
            ++count;
        }
    }
    T *matchingKeys = NULL;
    if (count > 0)
    {
        matchingKeys = new T[count]; // Allocate memory for matching keys
        int j = 0;
        for (int i = 0; i < currSize; ++i)
        {
            if (values[i] == value)
            {
                matchingKeys[j] = keys[i];
                ++j;
            }
        }
    }

    return Tuple<int, T *>(count, matchingKeys);
}
#endif