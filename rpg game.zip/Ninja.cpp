#include "Mage.h"
#include "Ninja.h"
#include "Brute.h"

Ninja::Ninja(std::string name, double health, double strength) : Soldier(name, health, strength)
{
    moveCount = 0;
}

bool Ninja::takeDamage(double damage)
{
    if (moveCount == 2)
    {
        moveCount = 0;
        return false;
    }
    moveCount++;
    return Soldier::takeDamage(damage);
}

Ninja &Ninja::operator=(const Ninja &ninja)
{
    if (this != &ninja)
    {
        Soldier::operator=(ninja);
        moveCount = ninja.moveCount;
    }
    return *this;
}
bool Ninja::isAlive() const
{
    return Soldier::isAlive();
}
bool Ninja::attack(Brute *brute)
{
    if (brute == NULL || !brute->isAlive() || sword == NULL)
    {
        return false;
    }
    double damage = sword->damage(strength);
    return brute->takeDamage(damage);
}

bool Ninja::attack(Ninja *ninja)
{
    if (ninja == NULL || !ninja->isAlive() || sword == NULL)
    {
        return false;
    }
    double damage = sword->damage(strength);
    return ninja->takeDamage(damage);
}

bool Ninja::attack(Mage *mage)
{
    if (mage == NULL || !mage->isAlive() || sword == NULL)
    {
        return false;
    }
    double damage = sword->damage(strength);
    return mage->takeDamage(damage);
}

void Ninja::arm(Sword *sword)
{
    Soldier::arm(sword);
}