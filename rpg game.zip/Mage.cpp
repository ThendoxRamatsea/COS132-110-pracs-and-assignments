#include "Mage.h"
#include "Brute.h"
#include "Ninja.h"
#include <sstream>
#include <string>

Mage::Mage(std::string name, double health, double strength)
    : Soldier(name, health, strength), shadowBone(NULL) {}

void Mage::armShadow(ShadowBone *newShadowBone)
{
    // Avoid deleting and reassigning the same object
    if (newShadowBone != shadowBone)
    {
        delete shadowBone; // Delete the old shadowBone if it exists
        shadowBone = newShadowBone;
    }
}

Mage &Mage::operator=(const Mage &mage)
{
    if (this != &mage)
    {
        // Call the base class assignment operator
        Soldier::operator=(mage);

        // Arm with the shadowBone from the other mage
        armShadow(mage.shadowBone);
    }
    return *this;
}

std::string Mage::printSoldier()
{
    std::stringstream ss;
    ss << Soldier::printSoldier();

    if (shadowBone != NULL)
    {
        ss << shadowBone->printSword();
    }

    return ss.str();
}

bool Mage::attack(Brute *brute)
{
    if (brute == NULL || !brute->isAlive() || (sword == NULL && shadowBone == NULL))
    {
        return false;
    }

    if (shadowBone != NULL)
    {
        double damage = shadowBone->damage(strength);
        if (brute->takeDamage(damage))
        {
            return true;
        }
    }

    if (sword != NULL)
    {
        double damage = sword->damage(strength);
        return brute->takeDamage(damage);
    }

    return false;
}

bool Mage::attack(Ninja *ninja)
{
    if (ninja == NULL || !ninja->isAlive() || (sword == NULL && shadowBone == NULL))
    {
        return false;
    }

    if (shadowBone != NULL)
    {
        double damage = shadowBone->damage(strength);
        if (ninja->takeDamage(damage))
        {
            return true;
        }
    }

    if (sword != NULL)
    {
        double damage = sword->damage(strength);
        return ninja->takeDamage(damage);
    }

    return false;
}

bool Mage::attack(Mage *mage)
{
    if (mage == NULL || !mage->isAlive() || sword == NULL)
    {
        return false;
    }

    double damage = sword->damage(strength);
    return mage->takeDamage(damage);
}
