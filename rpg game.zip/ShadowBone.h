#ifndef ShadowBone_H
#define ShadowBone_H
#include <iostream>
#include "Sword.h"
#include <string>

class ShadowBone : public Sword
{
private:
    double magicMultiplier;

public:
    ShadowBone(std::string name, double attack, double magicMultiplier);
    ShadowBone(const ShadowBone &SB);
    double damage(int playerlevel);
    std::string printSword();
};

#endif