#include "ShadowBone.h"
#include <sstream>

ShadowBone::ShadowBone(std::string name, double attack, double magicMultiplier)
    : Sword(name, attack), magicMultiplier(magicMultiplier) {}

ShadowBone::ShadowBone(const ShadowBone &shadowBone)
    : Sword(shadowBone), magicMultiplier(shadowBone.magicMultiplier) {}

double ShadowBone::damage(int playerStrength)
{
    double damage = attack + (attack * ((playerStrength * 0.1 + level * 0.2) + magicMultiplier));
    addXP(damage);
    return damage;
}

std::string ShadowBone::printSword()
{
    std::stringstream ss;
    ss << Sword::printSword();
    ss << "Magic Multiplier: " << magicMultiplier << "\n";
    return ss.str();
}
