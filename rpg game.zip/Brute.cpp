#include "Brute.h"
#include "Mage.h"
#include "Ninja.h"
#include <sstream>
#include <string>

Brute::Brute(std::string name, double health, double strength)
    : Soldier(name, health, strength), rageMeter(0.0) {}

std::string Brute::printSoldier()
{
    std::stringstream ss;
    ss << Soldier::printSoldier();
    ss << "Rage meter : " << rageMeter << "\n";
    return ss.str();
}

Brute &Brute::operator=(const Brute &brute)
{
    if (this != &brute)
    {
        Soldier::operator=(brute);
        rageMeter = brute.rageMeter;
    }
    return *this;
}

bool Brute::attack(Mage *mage)
{
    if (mage == NULL || !mage->isAlive() || sword == NULL)
    {
        return false;
    }

    double strengthUsed = strength;
    if (rageMeter >= 10)
    {
        strengthUsed = strength * 2 + strength * (rageMeter - 10) * 0.1;
    }

    double damage = sword->damage(strengthUsed);
    bool isKilled = mage->takeDamage(damage);

    if (isKilled)
    {
        rageMeter = 0;
    }
    else
    {
        rageMeter++;
    }

    return isKilled;
}

bool Brute::attack(Ninja *ninja)
{
    if (ninja == NULL || !ninja->isAlive() || sword == NULL)
    {
        return false;
    }

    double strengthUsed = strength;
    if (rageMeter >= 10)
    {
        strengthUsed = strength * 2 + strength * (rageMeter - 10) * 0.1;
    }

    double damage = sword->damage(strengthUsed);
    bool isKilled = ninja->takeDamage(damage);

    if (isKilled)
    {
        rageMeter = 0;
    }
    else
    {
        rageMeter++;
    }

    return isKilled;
}

bool Brute::attack(Brute *brute)
{
    if (brute == NULL || !brute->isAlive() || sword == NULL)
    {
        return false;
    }

    double strengthUsed = strength;
    if (rageMeter >= 10)
    {
        strengthUsed = strength * 2 + strength * (rageMeter - 10) * 0.1;
    }

    double damage = sword->damage(strengthUsed / 2);
    bool isKilled = brute->takeDamage(damage);

    if (isKilled)
    {
        rageMeter = 0;
    }
    else
    {
        rageMeter++;
    }

    return isKilled;
}
