#include <iostream>
#include <sstream>
#include <string>
#include "Sword.h"
#include "Mage.h"
#include "Brute.h"
#include "Ninja.h"
#include "Soldier.h"
#include "ShadowBone.h"

int main()
{
    ShadowBone shadowBone("Dark Blade", 60.0, 1.5);

    // Create a Mage, Brute, and Ninja
    Mage mage("Gandalf", 120.0, 40.0);
    Brute brute("Hulk", 150.0, 80.0);
    Ninja ninja("Ryu", 90.0, 60.0);

    // Arm the Mage with the ShadowBone
    mage.armShadow(&shadowBone);

    // Print information about the soldiers
    std::cout << "Mage Information:" << std::endl;
    std::cout << mage.printSoldier() << std::endl;

    std::cout << "Brute Information:" << std::endl;
    std::cout << brute.printSoldier() << std::endl;

    std::cout << "Ninja Information:" << std::endl;

    // Ninja attacks other soldiers
    bool mageSurvived = ninja.attack(&mage);
    bool bruteSurvived = ninja.attack(&brute);
    bool ninjaSurvived = brute.attack(&ninja);

    if (mageSurvived)
    {
    }
    else
    {
        std::cout << "Mage was defeated." << std::endl;
    }

    if (bruteSurvived)
    {
    }
    else
    {
        std::cout << "Brute was defeated." << std::endl;
    }

    if (ninjaSurvived)
    {
    }
    else
    {
        std::cout << "Ninja was defeated." << std::endl;
    }

    // Print updated information about the soldiers
    std::cout << "Updated Mage Information:" << std::endl;
    std::cout << mage.printSoldier() << std::endl;

    std::cout << "Updated Brute Information:" << std::endl;
    std::cout << brute.printSoldier() << std::endl;

    std::cout << "Updated Ninja Information:" << std::endl;

    // Print the number of alive and dead soldiers
    std::cout << "Alive Soldiers: " << Soldier::aliveSoldiers << std::endl;
    std::cout << "Dead Soldiers: " << Soldier::deadSoldiers << std::endl;
}