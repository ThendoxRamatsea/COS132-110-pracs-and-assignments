#include "Sword.h"
#include <cmath>
#include <sstream>
#include <string>

Sword::Sword(std::string name, double attack) : name(name), attack(attack), xp(0), level(1) {}

int Sword::getXPForNextLevel()
{
    return static_cast<int>(std::pow(2 * (level + 1), 3));
}

void Sword::addXP(double damage)
{
    xp += damage * 0.1;

    // Check if xp is enough for a level-up
    while (xp >= getXPForNextLevel())
    {
        level++;
        xp -= getXPForNextLevel();
    }
}

double Sword::damage(int playerStrength)
{
    double damageDealt = attack + (attack * (playerStrength * 0.1 + level * 0.2));
    addXP(damageDealt);
    return damageDealt;
}

std::string Sword::printSword()
{
    std::stringstream ss;
    ss << "Sword: " << name << "\n";
    ss << "Attack: " << attack << "\n";
    ss << "Level: " << level << "\n";
    ss << "XP: " << xp << "\n";
    return ss.str();
}

Sword::Sword(const Sword &sword) : name(sword.name), attack(sword.attack), xp(sword.xp), level(sword.level) {}
