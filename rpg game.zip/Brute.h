#ifndef Brute_H
#define Brute_H
class Mage;
class Ninja;
#include "Soldier.h"

class Brute : public Soldier
{
private:
    double rageMeter;

public:
    Brute(std::string name, double health, double strength);

    std::string printSoldier();

    Brute &operator=(const Brute &brute);

    bool attack(Mage *mage);
    bool attack(Ninja *ninja);
    bool attack(Brute *brute);
};

#endif