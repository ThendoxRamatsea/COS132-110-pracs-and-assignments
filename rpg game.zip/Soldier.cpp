#include "Sword.h"
#include "Soldier.h"
#include <sstream>
#include <string>
int Soldier::aliveSoldiers = 0;
int Soldier::deadSoldiers = 0;

Soldier::Soldier(std::string name, double health, double strength)
{
    aliveSoldiers++;
    this->name = name;
    this->health = health;
    this->strength = strength;
    this->sword = NULL;
}
Soldier::~Soldier()
{
    if (sword != NULL)
    {

        delete sword;
        sword = NULL;
    }
}
std::string Soldier::printSoldier()
{
    std::stringstream ss;
    ss << "Name : " << name << "\n";
    ss << "Health : " << health << "\n";
    ss << "Strength : " << strength << "\n";
    if (sword != NULL)
    {
        ss << sword->printSword();
    }
    return ss.str();
}
void Soldier::arm(Sword *newSword)
{

    if (newSword == this->sword)
    {
        return;
    }
    if (this->sword != NULL)
    {
        delete this->sword;
        this->sword = NULL;
    }

    if (newSword != NULL)
    {
        this->sword = newSword;
    }
    else
    {
        return;
    }
}
bool Soldier::takeDamage(double damage)
{

    if (damage < 0)
    {
        return false;
    }
    if (health < 0)
    {
        health = 0;
    }
    health -= damage;
    if (health <= 0)
    {
        health = 0;
        aliveSoldiers--;
        deadSoldiers++;
        return true;
    }
    return false;
}
bool Soldier::isAlive() const
{
    if (health > 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
Soldier &Soldier::operator=(const Soldier &soldier)
{
    // Check for self-assignment
    if (this == &soldier)
    {
        return *this;
    }

    // Deallocate the current sword if it exists
    if (this->sword != NULL)
    {
        delete this->sword;
    }

    // Copy simple fields
    this->name = soldier.name;
    this->health = soldier.health;
    this->strength = soldier.strength;

    // For the sword, we need to make a deep copy
    if (soldier.sword != NULL)
    {
        this->sword = new Sword(*(soldier.sword));
    }
    else
    {
        this->sword = NULL;
    }

    return *this;
}