#ifndef Sword_H
#define Sword_H
#include <iostream>

class Sword
{
private:
    std::string name;

protected:
    int level;
    double xp;
    double attack;
    int getXPForNextLevel();
    void addXP(double xp);

public:
    Sword() {}
    Sword(std::string name, double attack);
    Sword(const Sword &Sword);
    std::string printSword();
    double damage(int playerStrength);
};

#endif