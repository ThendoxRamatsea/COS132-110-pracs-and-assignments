#include "subscription.h"
#include <cmath>
#include "subscription.h"
#include "service.h"
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

subscription::subscription(std::string n, int bN, int r, char p, float d) : service(n, bN, r, p)
{

    yearDiscount = d;
}

subscription::~subscription()
{
}

float subscription::price(std::string s)
{
    std::stringstream ss(s);

    int time = 0;
    char period = 'y'; // Default period is years

    // Parse the input string to extract time and period
    ss >> time >> period;

    // Convert the period to lowercase
    period = tolower(period);

    float total = 0.0;

    if (period == 'y')
    { // Discount only applies for yearly subscriptions
        total = rate * (1 - yearDiscount);
    }
    else
    {
        total = rate;
    }

    return total;
}

void subscription::print()
{
    // Implement the logic for printing the information here
    std::cout << "Yearly Discount: " << yearDiscount << std::endl;
}
