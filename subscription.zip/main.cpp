#include "item.h"
#include <sstream>
#include <string>
#include "bulk.h"
#include "discountedProduct.h"
#include "labor.h"

#include "subscription.h"

int main()
{

    std::string binaryNum;
    int barcodeLength;
    bool *barcode = new bool[barcodeLength];
    // tesing the binary conversion
    int Bn = 13;
    std::stringstream ss;
    while (Bn)
    {
        ss << (Bn & 1);
        Bn >>= 1;
    }
    binaryNum = ss.str();
    int start = 0;
    int end = binaryNum.length() - 1;
    while (start < end)
    {
        std::swap(binaryNum[start], binaryNum[end]);
        start++;
        end--;
    }

    int counter;
    while (binaryNum[counter])
    {
        counter++;
    }
    barcodeLength = counter;

    for (int i = 0; i < barcodeLength; i++)
    {
        barcode[i] = (binaryNum[i] == '1');
    }
}
