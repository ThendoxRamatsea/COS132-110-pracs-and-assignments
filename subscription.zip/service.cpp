#include "service.h"
#include "item.h"
#include <sstream>
#include <string>
#include <iostream>
#include <iomanip>
float yearDiscount;
service::service(std::string n, int bN, int r, char p)
    : item(n, bN), rate(r), period(p) {}

service::~service() {}

void service::buy(std::string s)
{
    int time = 0;
    char unit = 'y'; // Default unit is years

    std::istringstream iss(s);
    iss >> time >> unit;

    unit = tolower(unit);

    float total = 0.0;
    float ratePerYear = rate;

    if (unit == 'h')
    {
        ratePerYear /= (24 * 7 * 4 * 12); // Convert rate per year to rate per hour
    }
    else if (unit == 'd')
    {
        ratePerYear /= (7 * 4 * 12); // Convert rate per year to rate per day
    }
    else if (unit == 'w')
    {
        ratePerYear /= (4 * 12); // Convert rate per year to rate per week
    }
    else if (unit == 'm')
    {
        ratePerYear /= 12; // Convert rate per year to rate per month
    }

    total = time * ratePerYear * (1.0 - 0.01 * yearDiscount); // Assuming yearDiscount is in percentage

    std::cout << "Bought " << time << " " << unit << " for $" << std::fixed << std::setprecision(2) << total << std::endl;
}

float service::price(std::string s)
{
    int time = 0;
    char unit = 'y'; // Default unit is years

    std::istringstream iss(s);
    iss >> time >> unit;

    unit = tolower(unit);

    float total = 0.0;
    float ratePerYear = rate;

    if (unit == 'h')
    {
        ratePerYear /= (24 * 7 * 4 * 12); // Convert rate per year to rate per hour
    }
    else if (unit == 'd')
    {
        ratePerYear /= (7 * 4 * 12); // Convert rate per year to rate per day
    }
    else if (unit == 'w')
    {
        ratePerYear /= (4 * 12); // Convert rate per year to rate per week
    }
    else if (unit == 'm')
    {
        ratePerYear /= 12; // Convert rate per year to rate per month
    }

    total = time * ratePerYear * (1.0 - 0.01 * yearDiscount); // Assuming yearDiscount is in percentage

    return total;
}
void service::print()
{
    std::cout << "Service Name: " << getName() << std::endl;
    std::cout << "Barcode: " << getBarcode() << std::endl;
    std::cout << "Rate: $" << rate << " per " << period << std::endl;
    std::cout << "Yearly Discount: " << yearDiscount << "%" << std::endl;
}