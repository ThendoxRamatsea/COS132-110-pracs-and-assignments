#include "item.h"
#include <iostream>
#include <sstream>
#include <string>
std::string binaryNum;

#include "item.h"
#include <iostream>
#include <sstream>
#include <string>

item::item(std::string n, int bN)
{
    name = n;
    std::stringstream ss;
    while (bN)
    {
        ss << (bN & 1);
        bN >>= 1;
    }
    std::string binaryNum = ss.str();
    int start = 0;
    int end = binaryNum.length() - 1;
    while (start < end)
    {
        std::swap(binaryNum[start], binaryNum[end]);
        start++;
        end--;
    }

    int counter = 0;
    while (binaryNum[counter])
    {
        counter++;
    }
    barcodeLength = counter;
    barcode = new bool[barcodeLength]; // Initialize the barcode array here

    for (int i = 0; i < barcodeLength; i++)
    {
        barcode[i] = (binaryNum[i] == '1');
        std::cout << barcode[i];
    }
}

item::~item()
{
    if (barcodeLength != 0)
    {
        delete[] barcode;
        barcode = NULL;
    }
}

std::string item::getName()
{
    return name;
}

std::string item::getBarcode()
{
    std::stringstream ss;
    ss << "[";
    for (int i = 0; i < barcodeLength; i++)
    {
        if (barcode[i] == 1)
        {
            ss << "|";
        }
        else
        {
            ss << " ";
        }
    }
    ss << "]";
    ss << "(" << binaryNum << ")";
    return ss.str();
}
