#include "product.h"
#include "discountedProduct.h"
#include <sstream>
#include <string>
#include <iostream>
#include <iomanip>

discountedProduct::discountedProduct(std::string n, int bN, int v, int a, float d) : product(n, bN, v, a)
{
    d = discount;
}
discountedProduct::~discountedProduct()
{
}
float discountedProduct::price(std::string s)
{
    std::stringstream ss(s);
    int numItems;
    ss >> numItems;

    float discountPrice = value * (1.0 - discount);
    float totalPrice = numItems * discountPrice;

    return totalPrice;
}
void discountedProduct::print()
{
    std::cout << getBarcode() << " discountedProduct : " << name << ". Value : R"
              << std::fixed << std::setprecision(2) << value << ". Amount : " << amount
              << ". Discount : " << std::fixed << std::setprecision(2) << (discount * 100)
              << " %." << std::endl;
}