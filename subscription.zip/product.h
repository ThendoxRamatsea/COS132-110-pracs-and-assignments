#ifndef product_h
#define product_h
#include <iostream>
#include "item.h"

class product : public item
{
protected:
    int value;
    int amount;

public:
    product(std::string n, int bN, int v, int a);
    ~product();
    virtual void buy(std::string s);
    virtual float price(std::string s);
    virtual void print();
};

#endif