#include "shop.h"
#include "product.h"
#include "service.h"
#include <iostream>
#include <sstream>
#include <iomanip>

// Constructor
shop::shop()
{
    items = NULL;
    numItems = 0;
}

// Destructor
shop::~shop()
{
    for (int i = 0; i < numItems; ++i)
    {
        delete items[i];
    }
    delete[] items;
}

// Function to get the index of an item
int shop::itemIndex(std::string n)
{
    for (int i = 0; i < numItems; ++i)
    {
        if (items[i]->getName() == n)
        {
            return i;
        }
    }
    return -1;
}

// Function to add an item
void shop::addItem(item *i)
{
    if (itemIndex(i->getName()) != -1)
    {
        std::cout << "Item already in shop" << std::endl;
        return;
    }

    item **temp = new item *[numItems + 1];
    for (int j = 0; j < numItems; ++j)
    {
        temp[j] = items[j];
    }

    // Determine the type of the item and create a new instance of the correct type
    product *prod = dynamic_cast<product *>(i);
    if (prod != NULL)
    {
        // temp[numItems] = new product(*prod);
    }
    else
    {
        service *serv = dynamic_cast<service *>(i);
        if (serv != NULL)
        {
            // temp[numItems] = new service(*serv);
        }
    }

    delete[] items;
    items = temp;
    numItems++;
}

// Function to add multiple items
void shop::addItems(item **i, int n)
{
    for (int j = 0; j < n; ++j)
    {
        addItem(i[j]);
    }
}

// Function to buy items
void shop::buyItems(std::string s)
{
    std::istringstream ss(s);
    std::string token;
    float total = 0.0;

    while (std::getline(ss, token, '|'))
    {
        std::string itemName = token.substr(0, token.find(":"));
        int index = itemIndex(itemName);

        if (index == -1)
        {
            std::cout << "Couldn't find " << itemName << std::endl;
            continue;
        }

        // Assuming Item has a buy() method that doesn't return a value
        items[index]->buy(token.substr(token.find(":") + 1));

        // Assuming Item has a price() method that returns the price
        total += items[index]->price(token.substr(token.find(":") + 1));
    }

    std::cout << "Total: R" << std::fixed << std::setprecision(2) << total << std::endl;
}

// Function to print items
void shop::printItems()
{
    for (int i = 0; i < numItems; ++i)
    {
        items[i]->print(); // Assuming Item has a print() method
    }
}

// Function to remove an item
void shop::removeItem(std::string s)
{
    int index = itemIndex(s);

    if (index == -1)
    {
        std::cout << "Item not found." << std::endl;
        return;
    }

    item **temp = new item *[numItems - 1];

    for (int i = 0, j = 0; i < numItems; ++i)
    {
        if (i != index)
        {
            temp[j++] = items[i];
        }
    }

    delete items[index];

    delete[] items;

    items = temp;

    numItems--;
}
