#include "labor.h"
#include "service.h"
#include <cmath>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

// Constructor
labor::labor(std::string n, int bN, int r, char p, int *wR, int num) : service(n, bN, r, p)
{

    workerRates = new int[num];
    for (int i = 0; i < num; i++)
    {
        workerRates[i] = wR[i];
    }
    numWorkers = num;
}

// Destructor
labor::~labor()
{
    delete[] workerRates;
}

// Price function
float labor::price(std::string s)
{
    float total = 0.0;
    int time = 0;

    // Extract the numerical part from the string
    std::stringstream ss(s.substr(0, s.size() - 1));
    ss >> time;

    // Assuming 'rate' is a member variable from the parent class that stores the base rate
    for (int i = 0; i < numWorkers; i++)
    {
        total += rate * workerRates[i];
    }
    return total;
}

// Print function
void labor::print()
{
    // Implement the logic for printing the information here
    std::cout << "Number of workers: " << numWorkers << std::endl;
    std::cout << "Worker rates: ";
    for (int i = 0; i < numWorkers; i++)
    {
        std::cout << workerRates[i] << " ";
    }
    std::cout << std::endl;
}
