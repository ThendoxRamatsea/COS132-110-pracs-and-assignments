#include "product.h"
#include "item.h"
#include <iostream>
#include <iomanip>
product::product(std::string n, int bN, int v, int a) : item(n, bN)
{
    v = value;
    a = amount;
}
product::~product()
{
    /*if (barcodeLength != 0)
     {
         delete[] barcode;
         barcode = NULL;
     }*/
}
void product::buy(std::string s)
{
    int x = 0;
    std::stringstream ss(s);
    ss >> x;

    if (x >= amount)
    {
        x = amount;
        amount = 0;
    }
    else
    {
        amount -= x;
    }

    std::cout << "Bought " << std::fixed << std::setprecision(2) << x << " " << name << " "
              << "for R" << std::fixed << std::setprecision(2) << price(s) << std::endl;
}

float product::price(std::string s)
{
    int x = 0;
    std::stringstream ss(s);
    ss >> x;

    int cost = 0;

    if (x > amount)
    {
        x = amount;
    }

    cost = x * value;

    return static_cast<float>(cost) / 100.0;
}

void product::print()
{
}