#ifndef LABOR_H
#define LABOR_H
#include "service.h"

#include <string>

class labor : public service
{

public:
    // Constructor
    labor(std::string n, int bN, int r, char p, int *wR, int num);

    // Destructor
    ~labor();

    // Member function declarations
    float price(std::string s);
    void print();

private:
    // Member variables
    int *workerRates;
    int numWorkers;
};

#endif // LABOR_H
