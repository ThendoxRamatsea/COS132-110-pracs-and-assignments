#include "bulk.h"
#include "product.h"
#include <sstream>
#include <string>
#include <iostream>
#include <iomanip>

bulk::bulk(std::string n, int bN, int v, int a, float dP, int dA) : product(n, bN, v, a)
{

    dP = discountPercentage;
    dA = discountAmount;
}
bulk::~bulk()
{
}
float bulk::price(std::string s)
{
    std::stringstream ss(s);
    int numItems;
    ss >> numItems;

    int numDiscountGroups = numItems / discountAmount;
    int numFullPriceItems = numItems % discountAmount;

    float discountPrice = value * (1.0 - discountPercentage);
    float totalPrice = numDiscountGroups * discountAmount * discountPrice + numFullPriceItems * value;

    return totalPrice;
}

void bulk::print()
{
    std::cout << getBarcode() << " bulk : " << name << ". Value : R"
              << std::fixed << std::setprecision(2) << value << ". Amount : " << amount
              << ". Discount : " << std::fixed << std::setprecision(2) << (discountPercentage * 100)
              << " %, on every group of " << discountAmount << " items." << std::endl;
}
