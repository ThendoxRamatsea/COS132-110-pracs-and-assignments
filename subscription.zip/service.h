#ifndef service_h
#define service_h
#include "item.h"
#include <iostream>
class service : public item
{
protected:
    int rate;
    char period;

public:
    service(std::string n, int bN, int r, char p);
    ~service();
    virtual void buy(std::string s);
    virtual float price(std::string s);
    virtual void print();
};

#endif