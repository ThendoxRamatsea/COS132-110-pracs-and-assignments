#ifndef SUBSCRIPTION_H
#define SUBSCRIPTION_H
#include "service.h"

#include <string>

class subscription : private service
{
public:
    // Constructor
    subscription(std::string n, int bN, int r, char p, float d);

    // Destructor
    ~subscription();

    // Member function declarations
    float price(std::string s);
    void print();

private:
    // Member variables
    float yearDiscount;
};

#endif // SUBSCRIPTION_H
